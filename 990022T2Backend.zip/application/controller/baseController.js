class baseController {
    constructor() {

    }
}

module.exports = baseController;